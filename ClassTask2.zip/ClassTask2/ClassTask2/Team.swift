//
//  Team.swift
//  ClassTask2
//
//  Created by Taibah Valley Academy on 3/5/25.
//

import SwiftUI

// Enum representing a types of teams
enum TeamType {
    case National
    case Club
    case Academy
}

// /class representing a Team
class Team: Identifiable{
    var id = UUID()
    var name: String
    var type: TeamType
    var players: [Player]
    
    init(name: String, type: TeamType, players: [Player] = []) {
        self.name = name
        self.type = type
        self.players = players
    }
}
