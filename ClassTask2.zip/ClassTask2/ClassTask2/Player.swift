//
//  Player.swift
//  ClassTask2
//
//  Created by Taibah Valley Academy on 3/5/25.
//


import SwiftUI


// Struct representing a Player
struct Player: Identifiable {
    var id = UUID()
    var name: String
    var score: Int
}
