//
//  ClassTask2App.swift
//  ClassTask2
//
//  Created by Taibah Valley Academy on 3/5/25.
//

import SwiftUI

@main
struct ClassTask2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
