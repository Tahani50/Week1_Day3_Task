//
//  ContentView.swift
//  ClassTask2
//
//  Created by Taibah Valley Academy on 3/5/25.
//

import SwiftUI

// SwiftUI view to display the teams and players
struct ContentView: View {
    @StateObject private var viewModel = ViewModel()
    var body: some View {
        NavigationView{
            List{
                ForEach(viewModel.teams){
                    team in Section(header: Text("\(team.name) in \(team.type)")){
                        ForEach(team.players){
                            player in HStack{
                                Text("\(player.name) has \(player.score) score")
                                    .foregroundColor(.blue)
                            }
                        }
                    }
                }
            }
            .navigationTitle(Text("Teams"))
        }
        .scrollContentBackground(.hidden)
    }
}

#Preview {
    ContentView()
}


