//
//  ViewModel.swift
//  ClassTask2
//
//  Created by Taibah Valley Academy on 3/5/25.
//

import SwiftUI

// ViewModel to manage and modify the list
class ViewModel: ObservableObject {
    @Published var teams: [Team] = [
        Team(name: "Team Alpha", type: .Club, players: [
            Player(name: "John", score: 40),
            Player(name: "Jane", score: 30),
        ]),
        Team(name: "Team Bravo", type: .Academy, players: [
            Player(name: "Alice", score: 50),
            Player(name: "Bob", score: 60),
        ]),
        Team(name: "Team Charlie", type: .National, players: [
            Player(name: "David", score: 20),
            Player(name: "Emma", score: 10),
        ])
    ]
}
